# Headshot Pro Mobile (Android)

Painel flutuante gamer (preto/vermelho/neon) + treinos próprios de mira e puxada.
Funciona de forma independente: não lê memória de jogos, não intercepta comandos
e não automatiza mira ou disparos.

## Gerar o APK
**Android Studio:** File > Open (esta pasta) > aguarde o sync > Build > Build APK(s)
**Terminal (JDK 17 + Android SDK 34):** `gradle assembleRelease`  (ou `assembleDebug`)
APK em `app/build/outputs/apk/release/`.
**Sem instalar nada:** suba a pasta para um repositório GitHub e rode a Action "Build APK".

## Uso
1. Abra o app, toque em CONCEDER PERMISSÃO e ative "Exibir sobre outros apps".
2. Toque em ABRIR PAINEL FLUTUANTE. Arraste pelo título; "—" minimiza em bolha; "✕" fecha.
3. Menus: AUXÍLIO DE MIRA / HEADSHOT PRO (abrem treinos), PRECISÃO (sensibilidade), CONFIGURAÇÕES (transparência etc.).
Tudo é salvo automaticamente.
