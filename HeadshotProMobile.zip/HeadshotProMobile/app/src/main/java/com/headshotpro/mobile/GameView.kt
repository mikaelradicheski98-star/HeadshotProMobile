package com.headshotpro.mobile

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Minigame de treino próprio (tela cheia, dentro do app).
 *  - "aim":  toque em alvos que aparecem/movem (reação + precisão).
 *  - "drag": arraste do corpo até a cabeça e solte (controle fino de puxada).
 * Nada aqui interage com outros apps.
 */
class GameView(
    private val act: Activity,
    private val mode: String,
    private val prefs: Prefs
) : View(act) {

    private enum class S { READY, RUN, DONE }

    private var state = S.READY
    private val rnd = java.util.Random()
    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private val topM: Float get() = dp(64f)

    private val bgPaint = Paint().apply { color = Color.parseColor("#050506") }
    private val gridPaint = Paint().apply { color = Color.argb(26, 255, 30, 60); strokeWidth = 1f }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }

    // estatísticas
    private var hits = 0
    private var misses = 0
    private var reactSum = 0L
    private var startT = 0L
    private var lastT = 0L
    private var doneAt = 0L
    private var newRecord = false

    // ---- aim ----
    private var tx = 0f; private var ty = 0f; private var tr = 0f
    private var tvx = 0f; private var tvy = 0f
    private var tSpawn = 0L
    private val rings = ArrayList<FloatArray>() // x, y, tempo relativo a startT
    private val durationMs: Long get() = prefs.duration * 1000L

    // ---- drag ----
    private var hx = 0f; private var hy = 0f; private var headR = 0f
    private var cx = 0f; private var cy = 0f
    private var lx = 0f; private var ly = 0f
    private var dragging = false
    private var round = 0
    private var dragT0 = 0L
    private var feedbackUntil = 0L
    private var lastHit = false
    private val trail = ArrayList<FloatArray>()
    private val gain: Float get() = 0.5f + prefs.sens(prefs.scope) / 100f * 1.5f

    // ------------------------------------------------------------------
    private fun startRun() {
        hits = 0; misses = 0; reactSum = 0; round = 0; newRecord = false
        rings.clear(); trail.clear()
        feedbackUntil = 0; dragging = false
        startT = SystemClock.uptimeMillis(); lastT = startT
        state = S.RUN
        if (mode == "aim") spawnTarget(startT) else newRound()
        invalidate()
    }

    private fun finish() {
        state = S.DONE
        doneAt = SystemClock.uptimeMillis()
        if (mode == "aim") {
            if (hits > prefs.bestAim) { prefs.bestAim = hits; newRecord = true }
        } else {
            if (hits > prefs.bestDrag) { prefs.bestDrag = hits; newRecord = true }
        }
    }

    // ---------------- AIM ----------------
    private fun spawnTarget(now: Long) {
        tr = dp(prefs.targetSize.toFloat()) / 2f
        tx = tr + rnd.nextFloat() * (width - 2 * tr).coerceAtLeast(1f)
        ty = topM + tr + rnd.nextFloat() * (height - topM - 2 * tr).coerceAtLeast(1f)
        val ang = rnd.nextFloat() * 6.2831f
        val sp = prefs.targetSpeed / 100f * dp(320f)
        tvx = cos(ang) * sp; tvy = sin(ang) * sp
        tSpawn = now
    }

    private fun updateAim(now: Long, dt: Float) {
        if (now - startT >= durationMs) { finish(); return }
        tx += tvx * dt; ty += tvy * dt
        if (tx < tr) { tx = tr; tvx = abs(tvx) } else if (tx > width - tr) { tx = width - tr; tvx = -abs(tvx) }
        if (ty < topM + tr) { ty = topM + tr; tvy = abs(tvy) } else if (ty > height - tr) { ty = height - tr; tvy = -abs(tvy) }
        if (now - tSpawn > 2200) { misses++; spawnTarget(now) }
    }

    private fun aimTouch(e: MotionEvent, now: Long) {
        if (e.actionMasked != MotionEvent.ACTION_DOWN) return
        if (hypot(e.x - tx, e.y - ty) <= tr * 1.2f) {
            hits++
            reactSum += now - tSpawn
            rings.add(floatArrayOf(tx, ty, (now - startT).toFloat()))
            spawnTarget(now)
        } else misses++
    }

    // ---------------- DRAG ----------------
    private fun newRound() {
        headR = dp(prefs.headSize.toFloat()) / 2f
        val margin = dp(50f) + headR
        hx = margin + rnd.nextFloat() * (width - 2 * margin).coerceAtLeast(1f)
        hy = topM + headR * 1.5f + rnd.nextFloat() * (height * 0.3f)
        cx = hx; cy = hy + headR * 4f
        trail.clear(); dragging = false
    }

    private fun updateDrag(now: Long) {
        if (feedbackUntil > 0 && now >= feedbackUntil) {
            feedbackUntil = 0
            if (round >= prefs.dragRounds) finish() else newRound()
        }
    }

    private fun dragTouch(e: MotionEvent, now: Long) {
        if (feedbackUntil > 0) return
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true; lx = e.x; ly = e.y; dragT0 = now
                trail.clear(); trail.add(floatArrayOf(cx, cy))
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                cx += (e.x - lx) * gain
                cy += (e.y - ly) * gain
                lx = e.x; ly = e.y
                cx = cx.coerceIn(0f, width.toFloat())
                cy = cy.coerceIn(topM * 0.5f, height.toFloat())
                trail.add(floatArrayOf(cx, cy))
                if (trail.size > 90) trail.removeAt(0)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                lastHit = hypot(cx - hx, cy - hy) <= headR
                if (lastHit) { hits++; reactSum += now - dragT0 } else misses++
                round++
                feedbackUntil = now + 450
            }
        }
    }

    // ---------------- Entrada ----------------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val now = SystemClock.uptimeMillis()
        if (e.actionMasked == MotionEvent.ACTION_DOWN && e.x > width - dp(56f) && e.y < dp(56f)) {
            act.finish(); return true
        }
        when (state) {
            S.READY -> if (e.actionMasked == MotionEvent.ACTION_DOWN) startRun()
            S.DONE -> if (e.actionMasked == MotionEvent.ACTION_DOWN && now - doneAt > 700) startRun()
            S.RUN -> if (mode == "aim") aimTouch(e, now) else dragTouch(e, now)
        }
        return true
    }

    // ---------------- Desenho ----------------
    private var canvasRef: Canvas? = null

    private fun text(s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        txt.textSize = dp(size)
        txt.color = color
        txt.textAlign = align
        var yy = y
        for (line in s.split("\n")) {
            canvasRef?.drawText(line, x, yy, txt)
            yy += dp(size) * 1.35f
        }
    }

    override fun onDraw(c: Canvas) {
        canvasRef = c
        val now = SystemClock.uptimeMillis()
        if (state == S.RUN) {
            val dt = ((now - lastT) / 1000f).coerceAtMost(0.05f)
            lastT = now
            if (mode == "aim") updateAim(now, dt) else updateDrag(now)
        }

        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        var gx = 0f
        while (gx < width) { c.drawLine(gx, 0f, gx, height.toFloat(), gridPaint); gx += dp(40f) }
        var gy = 0f
        while (gy < height) { c.drawLine(0f, gy, width.toFloat(), gy, gridPaint); gy += dp(40f) }

        when (state) {
            S.READY -> drawReady()
            S.RUN -> { if (mode == "aim") drawAim(c, now) else drawDrag(c); drawHud(c, now) }
            S.DONE -> drawDone()
        }
        drawClose(c)

        if (state == S.RUN) postInvalidateOnAnimation()
    }

    private fun drawClose(c: Canvas) {
        stroke.color = Theme.RED; stroke.strokeWidth = dp(2.5f)
        val x = width - dp(28f); val y = dp(28f); val s = dp(8f)
        c.drawLine(x - s, y - s, x + s, y + s, stroke)
        c.drawLine(x - s, y + s, x + s, y - s, stroke)
    }

    private fun drawHud(c: Canvas, now: Long) {
        if (mode == "aim") {
            val left = ((durationMs - (now - startT)) / 1000f).coerceAtLeast(0f)
            text("ACERTOS $hits   ERROS $misses   ${"%.0f".format(left)}s", width / 2f, dp(36f), 15f, Color.WHITE)
            fill.color = Theme.RED
            c.drawRect(0f, 0f, width * (1f - left / prefs.duration), dp(3f), fill)
        } else {
            text("RODADA ${minOf(round + 1, prefs.dragRounds)}/${prefs.dragRounds}   ACERTOS $hits   ${Prefs.SCOPES[prefs.scope]}",
                width / 2f, dp(36f), 14f, Color.WHITE)
        }
    }

    private fun drawAim(c: Canvas, now: Long) {
        // anéis de acerto
        val it = rings.iterator()
        while (it.hasNext()) {
            val r = it.next()
            val age = (now - startT) - r[2]
            if (age > 300) { it.remove(); continue }
            stroke.color = Theme.RED
            stroke.alpha = (255 * (1 - age / 300f)).toInt()
            stroke.strokeWidth = dp(3f)
            c.drawCircle(r[0], r[1], tr + age / 300f * dp(34f), stroke)
        }
        // alvo
        stroke.strokeWidth = dp(8f); stroke.color = Theme.RED; stroke.alpha = 60
        c.drawCircle(tx, ty, tr + dp(4f), stroke)
        fill.color = Theme.RED; fill.alpha = 255; c.drawCircle(tx, ty, tr, fill)
        fill.color = Color.WHITE; c.drawCircle(tx, ty, tr * 0.66f, fill)
        fill.color = Theme.RED; c.drawCircle(tx, ty, tr * 0.33f, fill)
    }

    private fun drawDrag(c: Canvas) {
        val bodyW = headR * 3.6f
        val body = RectF(hx - bodyW / 2, hy + headR * 1.2f, hx + bodyW / 2, hy + headR * 6.2f)
        fill.color = Color.parseColor("#1C1013"); fill.alpha = 255
        c.drawRoundRect(body, headR, headR, fill)
        stroke.color = Theme.DARK_RED; stroke.strokeWidth = dp(2f); stroke.alpha = 255
        c.drawRoundRect(body, headR, headR, stroke)
        // cabeça + zona
        fill.color = Color.parseColor("#1C1013"); c.drawCircle(hx, hy, headR, fill)
        stroke.color = Theme.RED; stroke.strokeWidth = dp(2f); c.drawCircle(hx, hy, headR, stroke)
        stroke.alpha = 70; stroke.strokeWidth = dp(7f); c.drawCircle(hx, hy, headR + dp(3f), stroke)
        stroke.alpha = 255

        // rastro
        if (trail.size > 1) {
            stroke.color = Theme.RED; stroke.strokeWidth = dp(2f); stroke.alpha = 110
            for (i in 1 until trail.size) {
                c.drawLine(trail[i - 1][0], trail[i - 1][1], trail[i][0], trail[i][1], stroke)
            }
            stroke.alpha = 255
        }
        // mira
        stroke.color = Color.WHITE; stroke.strokeWidth = dp(2f)
        c.drawCircle(cx, cy, dp(13f), stroke)
        c.drawLine(cx - dp(20f), cy, cx - dp(7f), cy, stroke)
        c.drawLine(cx + dp(7f), cy, cx + dp(20f), cy, stroke)
        c.drawLine(cx, cy - dp(20f), cx, cy - dp(7f), stroke)
        c.drawLine(cx, cy + dp(7f), cx, cy + dp(20f), stroke)
        fill.color = Theme.RED; c.drawCircle(cx, cy, dp(2.5f), fill)

        if (feedbackUntil > 0) {
            if (lastHit) text("HEADSHOT!", width / 2f, height * 0.62f, 28f, Theme.RED)
            else text("ERROU", width / 2f, height * 0.62f, 24f, Theme.MUTED)
        }
    }

    private fun drawReady() {
        val cxm = width / 2f; val cym = height / 2f
        if (mode == "aim") {
            text("AUXÍLIO DE MIRA", cxm, cym - dp(50f), 26f, Theme.RED)
            text("Toque nos alvos o mais rápido possível.\n${prefs.duration}s • alvo ${prefs.targetSize}dp • vel. ${prefs.targetSpeed}%",
                cxm, cym, 14f, Theme.MUTED)
        } else {
            text("HEADSHOT PRO", cxm, cym - dp(50f), 26f, Theme.RED)
            text("Arraste o dedo para puxar a mira do corpo\naté a cabeça e solte.\n" +
                "Mira ${Prefs.SCOPES[prefs.scope]} • ganho ${"%.2f".format(gain)}x • ${prefs.dragRounds} rodadas",
                cxm, cym, 14f, Theme.MUTED)
        }
        text("TOQUE PARA COMEÇAR", cxm, cym + dp(110f), 16f, Color.WHITE)
    }

    private fun drawDone() {
        val cxm = width / 2f; val cym = height / 2f
        val total = hits + misses
        val acc = if (total > 0) hits * 100 / total else 0
        val avg = if (hits > 0) reactSum / hits else 0
        text("TREINO CONCLUÍDO", cxm, cym - dp(80f), 24f, Theme.RED)
        text("Acertos: $hits   Erros: $misses\nPrecisão: $acc%\nTempo médio: ${avg}ms",
            cxm, cym - dp(30f), 16f, Color.WHITE)
        if (newRecord) text("NOVO RECORDE!", cxm, cym + dp(80f), 18f, Theme.RED)
        text("Toque para repetir  •  X para sair", cxm, cym + dp(120f), 13f, Theme.MUTED)
    }
}
