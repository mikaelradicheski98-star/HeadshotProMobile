package com.headshotpro.mobile

import android.content.Context

/** Configurações salvas automaticamente (SharedPreferences). */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("headshot_pro", Context.MODE_PRIVATE)

    private fun gi(k: String, d: Int) = sp.getInt(k, d)
    private fun pi(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    var opacity: Int get() = gi("opacity", 92); set(v) = pi("opacity", v)
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) { sp.edit().putBoolean("haptics", v).apply() }
    var animations: Boolean
        get() = sp.getBoolean("anim", true)
        set(v) { sp.edit().putBoolean("anim", v).apply() }

    // Treino de mira
    var targetSize: Int get() = gi("targetSize", 56); set(v) = pi("targetSize", v)
    var targetSpeed: Int get() = gi("targetSpeed", 30); set(v) = pi("targetSpeed", v)
    var duration: Int get() = gi("duration", 30); set(v) = pi("duration", v)
    var bestAim: Int get() = gi("bestAim", 0); set(v) = pi("bestAim", v)

    // Treino de puxada
    var headSize: Int get() = gi("headSize", 40); set(v) = pi("headSize", v)
    var dragRounds: Int get() = gi("dragRounds", 20); set(v) = pi("dragRounds", v)
    var scope: Int get() = gi("scope", 0); set(v) = pi("scope", v)
    var bestDrag: Int get() = gi("bestDrag", 0); set(v) = pi("bestDrag", v)

    // Sensibilidade do treino (0..100)
    fun sens(idx: Int) = gi("sens$idx", 50)
    fun setSens(idx: Int, v: Int) = pi("sens$idx", v)

    // Posição do painel
    var panelX: Int get() = gi("panelX", 24); set(v) = pi("panelX", v)
    var panelY: Int get() = gi("panelY", 160); set(v) = pi("panelY", v)

    fun resetSensitivity() { for (i in SCOPES.indices) setSens(i, 50) }
    fun resetAll() { sp.edit().clear().apply() }

    companion object {
        val SCOPES = listOf("GERAL", "RED DOT", "2X", "4X", "AWM")
    }
}
