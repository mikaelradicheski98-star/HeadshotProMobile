package com.headshotpro.mobile

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var toggleBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = Theme.BLACK
        window.navigationBarColor = Theme.BLACK

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        col.addView(Ui.label(this, "HEADSHOT PRO", 30f, Theme.RED, true).apply { letterSpacing = 0.12f })
        col.addView(Ui.label(this, "MOBILE", 14f, Color.WHITE, true).apply { letterSpacing = 0.5f })

        status = Ui.label(this, "", 13f, Theme.MUTED)
        col.addItem(status, 28)

        toggleBtn = Ui.button(this, prefs, "ABRIR PAINEL FLUTUANTE") { onToggle() }
        col.addItem(toggleBtn, 16)
        col.addItem(Ui.button(this, prefs, "TREINO DE MIRA", "Abrir direto, sem painel") { startTraining("aim") }, 12)
        col.addItem(Ui.button(this, prefs, "TREINO DE PUXADA", "Abrir direto, sem painel") { startTraining("drag") }, 12)

        col.addItem(Ui.label(this,
            "Este app é um painel visual e uma ferramenta de treino independente. " +
            "Ele não acessa a memória de nenhum jogo, não intercepta comandos e não automatiza mira ou disparos.",
            11f, Theme.MUTED), 28)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Theme.BLACK)
            addView(col)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        status.text = if (ok) "Permissão de sobreposição: ATIVA" else "Permissão de sobreposição: necessária"
        status.setTextColor(if (ok) Color.parseColor("#4CAF50") else Theme.RED)
        toggleBtn.text = when {
            !ok -> "CONCEDER PERMISSÃO"
            OverlayService.running -> "FECHAR PAINEL"
            else -> "ABRIR PAINEL FLUTUANTE"
        }
    }

    private fun onToggle() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            toggleBtn.postDelayed({ refresh() }, 300)
        } else {
            startForegroundService(Intent(this, OverlayService::class.java))
            moveTaskToBack(true)
        }
    }

    private fun startTraining(mode: String) {
        startActivity(Intent(this, TrainingActivity::class.java).putExtra("mode", mode))
    }

    private fun LinearLayout.addItem(v: View, top: Int) {
        addView(v, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) })
    }
}
