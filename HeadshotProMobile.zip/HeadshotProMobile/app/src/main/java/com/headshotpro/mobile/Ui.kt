package com.headshotpro.mobile

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

object Theme {
    val BLACK = Color.parseColor("#0A0A0C")
    val PANEL = Color.parseColor("#12070A")
    val RED = Color.parseColor("#FF1E3C")
    val DARK_RED = Color.parseColor("#5A0A16")
    val MUTED = Color.parseColor("#A8979B")
}

object Ui {
    fun box(ctx: Context, fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0) =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = ctx.dp(radiusDp).toFloat()
            if (strokeDp > 0) setStroke(ctx.dp(strokeDp), strokeColor)
        }

    fun label(ctx: Context, text: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(ctx).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    /** Botão neon com efeito ao toque e ao ativar. */
    fun button(ctx: Context, prefs: Prefs, title: String, sub: String? = null, onClick: () -> Unit): TextView {
        val full = if (sub != null) "$title\n$sub" else title
        val span = SpannableString(full)
        if (sub != null) {
            val s = title.length + 1
            span.setSpan(RelativeSizeSpan(0.72f), s, full.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            span.setSpan(ForegroundColorSpan(Theme.MUTED), s, full.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return TextView(ctx).apply {
            text = span
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.06f
            gravity = Gravity.CENTER
            setPadding(ctx.dp(10), ctx.dp(11), ctx.dp(10), ctx.dp(11))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Theme.DARK_RED, Theme.BLACK)
            ).apply {
                cornerRadius = ctx.dp(10).toFloat()
                setStroke(ctx.dp(1), Theme.RED)
            }
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
            setOnClickListener { v ->
                if (prefs.haptics) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                v.animate().alpha(0.55f).setDuration(60).withEndAction {
                    v.animate().alpha(1f).setDuration(120).start()
                }.start()
                onClick()
            }
        }
    }

    fun iconButton(ctx: Context, glyph: String, onClick: () -> Unit) =
        TextView(ctx).apply {
            text = glyph
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            minWidth = ctx.dp(32); minHeight = ctx.dp(32)
            background = box(ctx, Theme.DARK_RED, 8, Theme.RED, 1)
            setOnClickListener { onClick() }
        }

    fun slider(ctx: Context, name: String, lo: Int, hi: Int, value: Int, unit: String = "",
               onChange: (Int) -> Unit): LinearLayout {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(ctx)
        val valueView = label(ctx, "$value$unit", 12f, Theme.RED, true)
        row.addView(label(ctx, name, 12f, Theme.MUTED),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(valueView)
        val bar = SeekBar(ctx).apply {
            max = hi - lo
            progress = value - lo
            progressTintList = ColorStateList.valueOf(Theme.RED)
            thumbTintList = ColorStateList.valueOf(Theme.RED)
            progressBackgroundTintList = ColorStateList.valueOf(Theme.DARK_RED)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val x = p + lo
                    valueView.text = "$x$unit"
                    if (fromUser) onChange(x)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(row)
        col.addView(bar)
        return col
    }

    fun toggle(ctx: Context, name: String, value: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        var on = value
        val pill = TextView(ctx).apply {
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(ctx.dp(14), ctx.dp(5), ctx.dp(14), ctx.dp(5))
        }
        fun paint() {
            pill.text = if (on) "ON" else "OFF"
            pill.setTextColor(if (on) Color.WHITE else Theme.MUTED)
            pill.background = box(ctx, if (on) Theme.RED else Theme.BLACK, 14, Theme.RED, 1)
        }
        paint()
        pill.setOnClickListener { on = !on; paint(); onChange(on) }
        row.addView(label(ctx, name, 12f, Theme.MUTED),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(pill)
        return row
    }
}
