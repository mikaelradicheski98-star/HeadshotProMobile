package com.headshotpro.mobile

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Painel flutuante independente. Apenas exibe UI própria e abre telas de treino
 * do próprio app. Não lê nem altera outros apps, nem simula toques.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.headshotpro.mobile.STOP"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var lp: WindowManager.LayoutParams
    private var root: FrameLayout? = null
    private var content: LinearLayout? = null
    private var panelBg: GradientDrawable? = null
    private var glow: ValueAnimator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (root == null) createOverlay()
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        stopGlow()
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        running = false
        super.onDestroy()
    }

    // ---------- Notificação (obrigatória para serviço em primeiro plano) ----------
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Painel flutuante", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Headshot Pro Mobile")
            .setContentText("Painel de treino ativo")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Fechar", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- Janela flutuante ----------
    private fun createOverlay() {
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.panelX
            y = prefs.panelY
        }
        val r = FrameLayout(this)
        r.alpha = prefs.opacity / 100f
        root = r
        wm.addView(r, lp)
        showPanel()
    }

    private fun clampAndUpdate() {
        val r = root ?: return
        val m = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, (m.widthPixels - r.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (m.heightPixels - r.height).coerceAtLeast(0))
        runCatching { wm.updateViewLayout(r, lp) }
    }

    /** Arrasta a janela inteira; se não houve movimento, conta como toque. */
    private fun attachDrag(v: View, onTap: () -> Unit) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val ox = (e.rawX - downX).toInt(); val oy = (e.rawY - downY).toInt()
                    if (abs(ox) > slop || abs(oy) > slop) moved = true
                    if (moved) { lp.x = startX + ox; lp.y = startY + oy; clampAndUpdate() }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { prefs.panelX = lp.x; prefs.panelY = lp.y } else onTap()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Bolha minimizada ----------
    private fun showBubble() {
        val r = root ?: return
        stopGlow()
        content = null
        r.removeAllViews()
        val bubble = TextView(this).apply {
            text = "HP"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Theme.RED)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Theme.BLACK)
                setStroke(dp(2), Theme.RED)
            }
        }
        attachDrag(bubble) { showPanel() }
        r.addView(bubble, FrameLayout.LayoutParams(dp(52), dp(52)))
        r.post { clampAndUpdate() }
    }

    // ---------- Painel expandido ----------
    private fun showPanel() {
        val r = root ?: return
        stopGlow()
        r.removeAllViews()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Ui.box(this@OverlayService, Theme.PANEL, 16, Theme.RED, 2).also { panelBg = it }
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = Ui.label(this, "HEADSHOT PRO", 15f, Theme.RED, true).apply { letterSpacing = 0.12f }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Ui.iconButton(this, "—") { showBubble() })
        header.addView(Ui.iconButton(this, "✕") { stopSelf() },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { leftMargin = dp(6) })
        attachDrag(title) {}
        panel.addView(header)

        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = c
        panel.addView(c)
        panel.addView(Ui.label(this, "Ferramenta de treino independente", 10f, Theme.MUTED).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        r.addView(panel, FrameLayout.LayoutParams(dp(250), FrameLayout.LayoutParams.WRAP_CONTENT))
        showMain()
        startGlow()
        r.post { clampAndUpdate() }
    }

    private fun startGlow() {
        if (!prefs.animations) return
        glow = ValueAnimator.ofInt(90, 255).apply {
            duration = 1400
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val a = it.animatedValue as Int
                panelBg?.setStroke(dp(2), Color.argb(a, 255, 30, 60))
            }
            start()
        }
    }

    private fun stopGlow() { glow?.cancel(); glow = null }

    private fun LinearLayout.addItem(v: View, top: Int = 8) {
        addView(v, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = this@addItem.context.dp(top) })
    }

    // ---------- Telas ----------
    private fun showMain() {
        val c = content ?: return
        c.removeAllViews()
        c.addItem(Ui.button(this, prefs, "AUXÍLIO DE MIRA", "Treino de precisão") { showAimPage() }, 10)
        c.addItem(Ui.button(this, prefs, "HEADSHOT PRO", "Treino de puxada para capa") { showDragPage() })
        c.addItem(Ui.button(this, prefs, "PRECISÃO", "Ajuste de sensibilidade") { showPrecisionPage() })
        c.addItem(Ui.button(this, prefs, "CONFIGURAÇÕES", "Opções personalizadas") { showSettingsPage() })
    }

    private fun page(title: String, body: (LinearLayout) -> Unit) {
        val c = content ?: return
        c.removeAllViews()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(Ui.iconButton(this, "‹") { showMain() })
        row.addView(Ui.label(this, title, 13f, Color.WHITE, true).apply { setPadding(dp(10), 0, 0, 0) })
        c.addItem(row, 10)
        body(c)
    }

    private fun showAimPage() = page("AUXÍLIO DE MIRA") { c ->
        c.addItem(Ui.label(this, "Toque nos alvos o mais rápido que conseguir. Treino feito dentro do app.", 11f, Theme.MUTED))
        c.addItem(Ui.slider(this, "Tamanho do alvo", 20, 100, prefs.targetSize, " dp") { prefs.targetSize = it })
        c.addItem(Ui.slider(this, "Velocidade do alvo", 0, 100, prefs.targetSpeed, "%") { prefs.targetSpeed = it })
        c.addItem(Ui.slider(this, "Duração", 15, 60, prefs.duration, " s") { prefs.duration = it })
        c.addItem(Ui.label(this, "Recorde: ${prefs.bestAim} acertos", 12f, Theme.RED, true))
        c.addItem(Ui.button(this, prefs, "INICIAR TREINO") { launchTraining("aim") }, 10)
    }

    private fun showDragPage(): Unit = page("HEADSHOT PRO") { c ->
        c.addItem(Ui.label(this, "Arraste o dedo do corpo até a cabeça e solte. A sensibilidade vem da aba PRECISÃO.", 11f, Theme.MUTED))
        c.addItem(Ui.button(this, prefs, "MIRA: ${Prefs.SCOPES[prefs.scope]}", "toque para alternar") {
            prefs.scope = (prefs.scope + 1) % Prefs.SCOPES.size
            showDragPage()
        })
        c.addItem(Ui.slider(this, "Tamanho da cabeça", 16, 70, prefs.headSize, " dp") { prefs.headSize = it })
        c.addItem(Ui.slider(this, "Rodadas", 10, 40, prefs.dragRounds) { prefs.dragRounds = it })
        c.addItem(Ui.label(this, "Recorde: ${prefs.bestDrag} acertos", 12f, Theme.RED, true))
        c.addItem(Ui.button(this, prefs, "INICIAR TREINO") { launchTraining("drag") }, 10)
    }

    private fun showPrecisionPage(): Unit = page("PRECISÃO") { c ->
        c.addItem(Ui.label(this, "Sensibilidade usada nos treinos do app.", 11f, Theme.MUTED))
        for (i in Prefs.SCOPES.indices) {
            c.addItem(Ui.slider(this, Prefs.SCOPES[i], 0, 100, prefs.sens(i)) { prefs.setSens(i, it) })
        }
        c.addItem(Ui.button(this, prefs, "RESTAURAR PADRÃO") { prefs.resetSensitivity(); showPrecisionPage() }, 10)
    }

    private fun showSettingsPage(): Unit = page("CONFIGURAÇÕES") { c ->
        c.addItem(Ui.slider(this, "Transparência do painel", 30, 100, prefs.opacity, "%") {
            prefs.opacity = it
            root?.alpha = it / 100f
        })
        c.addItem(Ui.toggle(this, "Vibração ao tocar", prefs.haptics) { prefs.haptics = it })
        c.addItem(Ui.toggle(this, "Animação neon", prefs.animations) {
            prefs.animations = it
            if (it) startGlow() else { stopGlow(); panelBg?.setStroke(dp(2), Theme.RED) }
        })
        c.addItem(Ui.button(this, prefs, "RESETAR POSIÇÃO") {
            lp.x = dp(24); lp.y = dp(160)
            prefs.panelX = lp.x; prefs.panelY = lp.y
            clampAndUpdate()
        }, 10)
        c.addItem(Ui.button(this, prefs, "RESTAURAR TUDO") {
            prefs.resetAll(); root?.alpha = prefs.opacity / 100f; showSettingsPage()
        })
    }

    private fun launchTraining(mode: String) {
        startActivity(
            Intent(this, TrainingActivity::class.java)
                .putExtra("mode", mode)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
